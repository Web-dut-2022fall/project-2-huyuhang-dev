[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-c66648af7eb3fe8bc4f294546bfd86ef473780cde1dea487d3c4ff354943c9ae.svg)](https://classroom.github.com/online_ide?assignment_repo_id=9612972&assignment_repo_type=AssignmentRepo)
# project2-2021


项目重点：

commerce 文件夹

本地运行:

在项目目录下启动 commerce/manage.py
